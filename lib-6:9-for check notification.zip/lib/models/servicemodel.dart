class ServiceModel {
  ServiceModel({
    this.isSelected,
  });

  bool? isSelected;
}
