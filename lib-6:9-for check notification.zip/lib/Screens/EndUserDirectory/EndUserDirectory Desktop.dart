import 'dart:ffi';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:ge_assistant/Constants/appconst.dart';
import 'package:ge_assistant/Constants/popupmenu.dart';
import 'package:ge_assistant/models/crmloginmodel.dart';
import 'package:ge_assistant/models/directorymodel.dart';
import 'package:ge_assistant/services/apiservices.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:scrollable_positioned_list/scrollable_positioned_list.dart';

import '../../Constants/expandablelisttile.dart';

// int? selectedTileIndex = -1;
class UserDirectoryDesktop extends StatefulWidget {
  const UserDirectoryDesktop({Key? key, required this.director})
      : super(key: key);

  final List<DirectoryModel> director;

  @override
  State<UserDirectoryDesktop> createState() => _UserDirectoryDesktopState();
}

class _UserDirectoryDesktopState extends State<UserDirectoryDesktop> {
  IconData _expandedIcon = Icons.keyboard_arrow_down;
  String text = "";
  bool isSlted = false;
  ApiProvider client = ApiProvider();
  int _searchIndex = 0;
  final alphabets =
      List.generate(26, (index) => String.fromCharCode(index + 65));
  final ItemScrollController _itemScrollController = ItemScrollController();
  final ItemPositionsListener _itemPositionsListener =
      ItemPositionsListener.create();
  List<Datum> check = [];
  late List<DirectoryModel> directoryFilter = [];
  late List<DirectoryModel> actualDirectory = [];
  late List<Record> compareLists = [];
  late Future<Crmuserslogin> status;
  @override
  void initState() {
    actualDirectory.addAll(widget.director);
    directoryFilter = widget.director;
    status = client.getloginusers(AppConstants.token ?? "");
    super.initState();
  }

  void setSearchIndex(String searchLetter) {
    setState(() {
      _searchIndex = (directoryFilter.first.data ?? [])
          .indexWhere((element) => element.employeename?[0] == searchLetter);
      print(_searchIndex);
      if (_searchIndex >= 0) _itemScrollController.jumpTo(index: _searchIndex);
    });
  }

  @override
  Widget build(BuildContext context) {
    var listgroup = AutoSizeGroup();
    var headinggroup = AutoSizeGroup();

    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    List<Datum> modeltemp = actualDirectory.first.data ?? [];
    return Scaffold(
        backgroundColor: const Color(0xff303030),
        // backgroundColor: Colors.white,
        // appBar: AppBar(
        //   title: Text('image/end user directory banner.jpg'),
        // ),
        body: Column(
          children: [
            // FutureBuilder(
            //     future: client.getloginusers(),
            //     builder: (context, snapshot) {
            //       if (snapshot.hasData) {
            //         if (snapshot.connectionState == ConnectionState.waiting) {
            //           print("Loading......");
            //         }
            //         if (snapshot.connectionState == ConnectionState.done) {
            //           print(snapshot.data?.count.toString());
            //           return SizedBox(
            //             height: 0,
            //             child: ListView.builder(
            //                 itemCount: directoryFilter.length,
            //                 itemBuilder: (context, index) {
            //                   //print(snapshot.data?.records?[index].sLoginName)
            // List<String> comparisonResults = actualDirectory
            //     .first.data!
            //     .map((object1) =>
            //         (snapshot.data?.records ?? []).any(
            //                 (element) =>
            //                     object1.crmusercode ==
            //                     element.sLoginName)
            //             ? 'x'
            //             : '0')
            //     .toList();

            //                   print('Comparison results: $comparisonResults');
            //                 }),
            //           );
            //         }
            //         return SizedBox();
            //       } else if (snapshot.hasError) {
            //         return const Center(
            //           child: Text('Error'),
            //         );
            //       } else {
            //         const SizedBox.shrink();
            //       }
            //       return const SizedBox.shrink();
            //     }),
            Container(
                width: double.maxFinite,
                height: MediaQuery.of(context).size.height * 0.25,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                  image: AssetImage("image/end user directory banner.jpg"),
                  fit: BoxFit.fill,
                )),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        SizedBox(
                            width: MediaQuery.of(context).size.width * 0.4,
                            height: MediaQuery.of(context).size.height * 0.1,
                            // color: Colors.red,
                            child: const Image(
                                image: AssetImage(
                                    "image/GE office assistant white.png"))),
                        Padding(
                          padding: EdgeInsets.only(
                              right: MediaQuery.of(context).size.width * 0.03),
                          child: PopUpMen(
                            menuList: [
                              PopupMenuItem(
                                  child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        "Hello ${AppConstants.name}"
                                            .toUpperCase(),
                                        style: TextStyle(color: Colors.black),
                                      ),
                                      Icon(Icons.close)
                                    ],
                                  ),
                                  // Row(
                                  //   children: [
                                  //     Text(
                                  //       AppConstants.username.toString(),
                                  //       style: TextStyle(color: Colors.black),
                                  //     ),
                                  //   ],
                                  // )
                                ],
                              )),
                              const PopupMenuItem(
                                value: 1,
                                child: ListTile(
                                  leading: Icon(
                                    Icons.logout,
                                  ),
                                  title: Text("LogOut",
                                      style: TextStyle(color: Colors.black)),
                                ),
                              ),
                            ],
                            icon: const Icon(
                              Icons.menu,
                              color: Colors.white,
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * .15,
                      // color: Colors.blue,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                AutoSizeText(
                                  "Directory",
                                  style: GoogleFonts.inriaSerif(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 96,
                                      color: Colors.white),
                                  minFontSize: 5,
                                )
                              ],
                            ),
                          ),
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                AutoSizeText(
                                  "Service",
                                  style: GoogleFonts.inriaSerif(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 96,
                                      color: Colors.white),
                                  minFontSize: 5,
                                )
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                )),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.018,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.011),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Padding(
                        padding: EdgeInsets.only(
                            left: MediaQuery.of(context).size.width * 0.08),
                        child: SizedBox(
                          width: MediaQuery.of(context).size.width > 1276.8
                              ? MediaQuery.of(context).size.width * 0.08
                              : 100,
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            style: ElevatedButton.styleFrom(
                              elevation: 4,
                              backgroundColor: const Color(0xff303030),
                              // foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(
                                    17), // Set border radius of 3
                                side: const BorderSide(
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Icon(Icons.arrow_back_rounded,
                                    size: MediaQuery.of(context).size.width >
                                            1276.8
                                        ? MediaQuery.of(context).size.width *
                                            0.01
                                        : 13),
                                const SizedBox(width: 8),
                                Expanded(
                                    child: MediaQuery.of(context).size.width >
                                            1276.8
                                        ? Text('Go back',
                                            maxLines: 1,
                                            style: TextStyle(
                                                fontSize: MediaQuery.of(context)
                                                        .size
                                                        .width *
                                                    0.01))
                                        : const Text(
                                            'Go back',
                                            maxLines: 1,
                                            style: TextStyle(fontSize: 10),
                                          )),
                              ],
                            ),
                          ),
                        )),
                  ),
                ),
              ],
            ),
            Column(children: [
              Container(
                width: double.infinity,
                height: 50,
                alignment: Alignment.center,
                padding: const EdgeInsets.only(right: 20),
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  children: alphabets
                      .map((alphabet) => InkWell(
                            onTap: () {
                              setSearchIndex(alphabet);
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: AutoSizeText(
                                alphabet,
                                style: GoogleFonts.inriaSerif(
                                    fontSize: 20, color: Colors.white),
                                maxLines: 1,
                                group: listgroup,
                              ),

                              //  Text(
                              //   alphabet,
                              //   style: const TextStyle(
                              //       fontSize: 16),
                              // ),
                            ),
                          ))
                      .toList(),
                ),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.6,
                height: MediaQuery.of(context).size.height * 0.08,
                child: TextFormField(
                  style: const TextStyle(color: Colors.white),
                  onChanged: (value) {
                    if (value.isEmpty) {
                      setState(() {
                        directoryFilter.clear();
                        directoryFilter.addAll(actualDirectory);
                      });
                    } else {
                      List<Datum> dummy = modeltemp
                          .where((Datum element) => (element.employeename ?? "")
                              .toLowerCase()
                              .contains(value.toLowerCase()))
                          .toList();

                      setState(() {
                        directoryFilter.clear();
                        directoryFilter.addAll([DirectoryModel(data: dummy)]);
                      });
                      //directoryFilter.clear();
                    }

                    // (directoryFilter ?? []).first.addAll(dummy);
                    // modeltemp.where((Datum element) => (element.employeename ?? [])(other))
                  },
                  decoration: InputDecoration(
                    hintText: "Enter name...",
                    hintStyle:
                        const TextStyle(color: Colors.white, fontSize: 20),
                    // contentPadding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),

                    suffixIcon: Stack(
                      alignment: Alignment.center,
                      children: [
                        const Icon(
                          Icons.search,
                          color: Colors.white,
                        ), // First widget
                        Positioned(
                          right: 38,
                          child: SizedBox(
                            height: MediaQuery.of(context).size.height * 0.15,
                            width: 2,
                            child: Container(
                              color: Colors.white,
                            ),
                          ), // Second widget
                        ),
                      ],
                    ),
                    border: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(50)),
                    enabledBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(50)),
                    focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(color: Colors.white),
                        borderRadius: BorderRadius.circular(50)),
                  ),
                  //onChanged: searchcontact(),
                ),
              ),
              Padding(
                padding: MediaQuery.of(context).size.width > 1300
                    ? EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.2,
                        right: MediaQuery.of(context).size.width * 0.2)
                    : EdgeInsets.only(
                        left: MediaQuery.of(context).size.width * 0.1,
                        right: MediaQuery.of(context).size.width * 0.1),
                child: ExpansionTile(
                  trailing: Visibility(
                    visible: false,
                    child: SizedBox(
                        child: SvgPicture.asset(
                            'image/iconmonstr-angel-down-circle-thin.svg')),
                  ),
                  title: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                            child: AutoSizeText(
                          "Name",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.inriaSerif(
                              fontSize: 20, color: Colors.white),
                          maxLines: 1,
                          group: listgroup,
                        )),
                      ),
                      Expanded(
                        child: SizedBox(
                            child: AutoSizeText(
                          "Branch",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.inriaSerif(
                              fontSize: 20, color: Colors.white),
                          maxLines: 1,
                          group: listgroup,
                        )),
                      ),
                      Expanded(
                        child: SizedBox(
                            child: AutoSizeText(
                          "Department",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.inriaSerif(
                              fontSize: 20, color: Colors.white),
                          maxLines: 1,
                          group: listgroup,
                        )),
                      ),
                      Expanded(
                        child: SizedBox(
                            child: AutoSizeText(
                          "Extension",
                          textAlign: TextAlign.center,
                          style: GoogleFonts.inriaSerif(
                              fontSize: 20, color: Colors.white),
                          maxLines: 2,
                          group: listgroup,
                        )),
                      ),
                      Expanded(
                        child: SizedBox(
                          child: AutoSizeText(
                            "Status",
                            textAlign: TextAlign.center,
                            style: GoogleFonts.inriaSerif(
                                fontSize: 20, color: Colors.white),
                            maxLines: 1,
                            group: listgroup,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ]),
            Expanded(
              child: ScrollablePositionedList.builder(
                  itemScrollController: _itemScrollController,
                  itemPositionsListener: _itemPositionsListener,
                  itemCount: (directoryFilter.first.data ?? []).length,
                  itemBuilder: (context, index) {
                    //myList..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));

                    final sortedItems = (directoryFilter.first.data ?? [])
                      ..sort((a, b) => a.employeename!
                          .toLowerCase()
                          .compareTo(b.employeename!.toLowerCase()));
                    final directoryList = sortedItems[index];
                    //
                    return Padding(
                      padding: MediaQuery.of(context).size.width > 1300
                          ? EdgeInsets.only(
                              left: MediaQuery.of(context).size.width * .2,
                              right: MediaQuery.of(context).size.width * .2)
                          : EdgeInsets.only(
                              left: MediaQuery.of(context).size.width * .1,
                              right: MediaQuery.of(context).size.width * .1),
                      child: Container(
                          color: index % 2 == 0
                              ? const Color(0xff5A5858)
                              : const Color(0xff424242),
                          child: customListExpanded(
                              context, directoryList, listgroup, status)),
                    );
                  }),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 8),
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.5,
                height: MediaQuery.of(context).size.height * 0.1,
                child: Align(
                  alignment: Alignment.center,
                  child: AutoSizeText(
                    "Copyright 2023 © German Experts. All Rights Reserved",
                    style: GoogleFonts.inter(
                      textStyle: const TextStyle(color: Color(0xffFFFFFF)),
                    ),
                    maxLines: 1,
                    minFontSize: 2,
                  ),
                ),
              ),
            ),
          ],
        ));
  }

  // setSearchIndex(String searchLetter, Datum names) {
  //   print(names);
  //   setState(() {
  //     _searchIndex = check.indexWhere((element) => element[0] == searchLetter);
  //     if (_searchIndex >= 0) {
  //       _itemScrollController.jumpTo(index: _searchIndex);
  //     }
  //   });
  // }
}

// searchcontact(String query, List<Datum> datums) {
//   final suggestions = datums.where((element) {
//     final contactname = element.employeename?.toLowerCase();
//     final input = query.toLowerCase();
//     return contactname!.contains(input);
//   }).toList();
// }
