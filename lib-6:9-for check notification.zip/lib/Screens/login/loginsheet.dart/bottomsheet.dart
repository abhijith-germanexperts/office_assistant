import 'package:flutter/material.dart';

loginModalBottomSheet(context) {
  showModalBottomSheet(
      context: context,
      builder: (BuildContext bc) {
        return Container(
            height: double.infinity,
            color: Colors.transparent,
            child: Center(
              child: Text("cdsv"),
            ));
      });
}
