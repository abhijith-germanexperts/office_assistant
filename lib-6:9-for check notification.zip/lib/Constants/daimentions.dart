
const mobileWidth =610;