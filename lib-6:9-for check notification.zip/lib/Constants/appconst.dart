class AppConstants {
  static var username;
  static var name;
  static var token;
  static var roleId;
  static var officeId;
  static var pantryId;
  static var userPantryId;
  static var usercategoryId;
  static var fcmtoken;
}
